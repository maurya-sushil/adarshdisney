import React from 'react'

function movie() {
    return (
        <div>
            
        </div>
    )
}

export default movie
