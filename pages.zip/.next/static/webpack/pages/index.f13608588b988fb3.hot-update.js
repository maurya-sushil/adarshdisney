/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./components/TV.js":
/*!**************************!*\
  !*** ./components/TV.js ***!
  \**************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* module decorator */ module = __webpack_require__.nmd(module);


;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": function() { return /* binding */ Home; }\n/* harmony export */ });\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ \"./node_modules/react/jsx-runtime.js\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ \"./node_modules/next/head.js\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Header */ \"./components/Header.js\");\n/* harmony import */ var _components_Brands__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Brands */ \"./components/Brands.js\");\n/* harmony import */ var _components_Slider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Slider */ \"./components/Slider.js\");\n/* harmony import */ var _components_MoviesCollection__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/MoviesCollection */ \"./components/MoviesCollection.js\");\n/* harmony import */ var _components_TV__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/TV */ \"./components/TV.js\");\n/* harmony import */ var _components_TV__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_components_TV__WEBPACK_IMPORTED_MODULE_6__);\n/* module decorator */ module = __webpack_require__.hmd(module);\n\n\n\n\n\n\n\nfunction Home() {\n    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(\"div\", {\n        __source: {\n            fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n            lineNumber: 12,\n            columnNumber: 5\n        },\n        __self: this,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {\n                __source: {\n                    fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                    lineNumber: 13,\n                    columnNumber: 7\n                },\n                __self: this,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"title\", {\n                        __source: {\n                            fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                            lineNumber: 14,\n                            columnNumber: 9\n                        },\n                        __self: this,\n                        children: \"Resumer Pro\"\n                    }),\n                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"meta\", {\n                        name: \"description\",\n                        content: \"Generated by create next app\",\n                        __source: {\n                            fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                            lineNumber: 15,\n                            columnNumber: 9\n                        },\n                        __self: this\n                    }),\n                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"link\", {\n                        rel: \"icon\",\n                        href: \"/favicon.ico\",\n                        __source: {\n                            fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                            lineNumber: 16,\n                            columnNumber: 9\n                        },\n                        __self: this\n                    })\n                ]\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_Header__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n                __source: {\n                    fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                    lineNumber: 18,\n                    columnNumber: 9\n                },\n                __self: this\n            }),\n            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(\"main\", {\n                className: \"relative min-h-screen after:bg-home after:bg-center after:bg-cover after:bg-no-repeat after:bg-fixed after:absolute after:inset-0 after:z-[-1]\",\n                __source: {\n                    fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                    lineNumber: 19,\n                    columnNumber: 9\n                },\n                __self: this,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_Slider__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n                        __source: {\n                            fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                            lineNumber: 20,\n                            columnNumber: 11\n                        },\n                        __self: this\n                    }),\n                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_Brands__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n                        __source: {\n                            fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                            lineNumber: 22,\n                            columnNumber: 11\n                        },\n                        __self: this\n                    }),\n                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_MoviesCollection__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {\n                        __source: {\n                            fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                            lineNumber: 23,\n                            columnNumber: 11\n                        },\n                        __self: this\n                    }),\n                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((_components_TV__WEBPACK_IMPORTED_MODULE_6___default()), {\n                        __source: {\n                            fileName: \"C:\\\\Users\\\\rathi\\\\Downloads\\\\Pictures\\\\ADARSH\\\\Ram\\\\seeta\\\\pages\\\\index.js\",\n                            lineNumber: 24,\n                            columnNumber: 11\n                        },\n                        __self: this\n                    })\n                ]\n            })\n        ]\n    }));\n};\n_c = Home;\nvar _c;\n$RefreshReg$(_c, \"Home\");\n\n\n;\n    var _a, _b;\n    // Legacy CSS implementations will `eval` browser code in a Node.js context\n    // to extract CSS. For backwards compatibility, we need to check we're in a\n    // browser context before continuing.\n    if (typeof self !== 'undefined' &&\n        // AMP / No-JS mode does not inject these helpers:\n        '$RefreshHelpers$' in self) {\n        var currentExports = module.__proto__.exports;\n        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;\n        // This cannot happen in MainTemplate because the exports mismatch between\n        // templating and execution.\n        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);\n        // A module can be accepted automatically based on its exports, e.g. when\n        // it is a Refresh Boundary.\n        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {\n            // Save the previous exports on update so we can compare the boundary\n            // signatures.\n            module.hot.dispose(function (data) {\n                data.prevExports = currentExports;\n            });\n            // Unconditionally accept an update to this module, we'll check if it's\n            // still a Refresh Boundary later.\n            module.hot.accept();\n            // This field is set when the previous version of this module was a\n            // Refresh Boundary, letting us know we need to check for invalidation or\n            // enqueue an update.\n            if (prevExports !== null) {\n                // A boundary can become ineligible if its exports are incompatible\n                // with the previous exports.\n                //\n                // For example, if you add/remove/change exports, we'll want to\n                // re-execute the importing modules, and force those components to\n                // re-render. Similarly, if you convert a class component to a\n                // function, we want to invalidate the boundary.\n                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {\n                    module.hot.invalidate();\n                }\n                else {\n                    self.$RefreshHelpers$.scheduleUpdate();\n                }\n            }\n        }\n        else {\n            // Since we just executed the code for the module, it's possible that the\n            // new exports made it ineligible for being a boundary.\n            // We only care about the case when we were _previously_ a boundary,\n            // because we already accepted this update (accidental side effect).\n            var isNoLongerABoundary = prevExports !== null;\n            if (isNoLongerABoundary) {\n                module.hot.invalidate();\n            }\n        }\n    }\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQTRCO0FBQ2E7QUFDQTtBQUNBO0FBQ29CO0FBQzVCO0FBSWxCLFFBQVEsQ0FBQ00sSUFBSSxHQUFHLENBQUM7SUFDOUIsTUFBTSx1RUFDSEMsQ0FBRzs7Ozs7Ozs7a0ZBQ0RQLGtEQUFJOzs7Ozs7Ozt5RkFDRlEsQ0FBSzs7Ozs7OztrQ0FBQyxDQUFXOzt5RkFDakJDLENBQUk7d0JBQUNDLElBQUksRUFBQyxDQUFhO3dCQUFDQyxPQUFPLEVBQUMsQ0FBOEI7Ozs7Ozs7O3lGQUM5REMsQ0FBSTt3QkFBQ0MsR0FBRyxFQUFDLENBQU07d0JBQUNDLElBQUksRUFBQyxDQUFjOzs7Ozs7Ozs7O2lGQUVuQ2IsMERBQU07Ozs7Ozs7O2tGQUNOYyxDQUFJO2dCQUFDQyxTQUFTLEVBQUMsQ0FBZ0o7Ozs7Ozs7O3lGQUM3SmIsMERBQU07Ozs7Ozs7O3lGQUVORCwwREFBTTs7Ozs7Ozs7eUZBQ05FLG9FQUFnQjs7Ozs7Ozs7eUZBQ2hCQyx1REFBRTs7Ozs7Ozs7Ozs7O0FBS2IsQ0FBQztLQW5CdUJDLElBQUkiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanM/YmVlNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXG5pbXBvcnQgSGVhZGVyIGZyb20gJy4uL2NvbXBvbmVudHMvSGVhZGVyJ1xuaW1wb3J0IEJyYW5kcyBmcm9tICcuLi9jb21wb25lbnRzL0JyYW5kcydcbmltcG9ydCBTbGlkZXIgZnJvbSAnLi4vY29tcG9uZW50cy9TbGlkZXInXG5pbXBvcnQgTW92aWVzQ29sbGVjdGlvbiBmcm9tICcuLi9jb21wb25lbnRzL01vdmllc0NvbGxlY3Rpb24nXG5pbXBvcnQgVFYgZnJvbSAnLi4vY29tcG9uZW50cy9UVidcblxuXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiA+XG4gICAgICA8SGVhZD5cbiAgICAgICAgPHRpdGxlPlJlc3VtZXIgUHJvPC90aXRsZT5cbiAgICAgICAgPG1ldGEgbmFtZT1cImRlc2NyaXB0aW9uXCIgY29udGVudD1cIkdlbmVyYXRlZCBieSBjcmVhdGUgbmV4dCBhcHBcIiAvPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICAgIDxIZWFkZXIvPlxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4taC1zY3JlZW4gYWZ0ZXI6YmctaG9tZSBhZnRlcjpiZy1jZW50ZXIgYWZ0ZXI6YmctY292ZXIgYWZ0ZXI6Ymctbm8tcmVwZWF0IGFmdGVyOmJnLWZpeGVkIGFmdGVyOmFic29sdXRlIGFmdGVyOmluc2V0LTAgYWZ0ZXI6ei1bLTFdXCI+XG4gICAgICAgICAgPFNsaWRlciAvPlxuICAgICAgICBcbiAgICAgICAgICA8QnJhbmRzIC8+XG4gICAgICAgICAgPE1vdmllc0NvbGxlY3Rpb24gLz5cbiAgICAgICAgICA8VFYvPlxuICBcbiAgICAgICAgICAgICA8L21haW4+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJIZWFkIiwiSGVhZGVyIiwiQnJhbmRzIiwiU2xpZGVyIiwiTW92aWVzQ29sbGVjdGlvbiIsIlRWIiwiSG9tZSIsImRpdiIsInRpdGxlIiwibWV0YSIsIm5hbWUiLCJjb250ZW50IiwibGluayIsInJlbCIsImhyZWYiLCJtYWluIiwiY2xhc3NOYW1lIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ })

});