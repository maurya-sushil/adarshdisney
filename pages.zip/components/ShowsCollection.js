

function ShowsCollection() {
  return <div></div>;
}

export default ShowsCollection;
